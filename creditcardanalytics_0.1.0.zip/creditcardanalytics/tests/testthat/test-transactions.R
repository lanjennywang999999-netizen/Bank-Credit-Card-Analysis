test_that("clean_transactions removes duplicate records", {
  x <- data.frame(
    trans_num = c("a", "a"),
    cc_num = c("1", "1"),
    trans_date_trans_time = c("2026-01-02", "2026-01-02"),
    category = c("food", "food"),
    amt = c(10, 10),
    merch_lat = c(1, 1),
    merch_long = c(2, 2),
    merch_zipcode = c(2000, 2000),
    is_fraud = c(0, 0),
    reward_points = c(1, 1),
    cashback_amt = c(0.1, 0.1)
  )
  expect_equal(nrow(clean_transactions(x)), 1)
})

test_that("aggregate_transactions counts active days", {
  x <- data.frame(
    cc_num = c("1", "1"),
    category = c("food", "food"),
    trans_date_trans_time = as.Date(c("2026-01-02", "2026-01-03")),
    amt = c(10, 20),
    reward_points = c(1, 2),
    cashback_amt = c(0.1, 0.2)
  )
  out <- aggregate_transactions(x)
  expect_equal(out$tranDay_Cnt, 2)
  expect_equal(out$days_in_month, 31)
})
