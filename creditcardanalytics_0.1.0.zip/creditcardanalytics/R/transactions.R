#' Clean credit-card transaction records
#'
#' Removes duplicate transaction rows using the business columns supplied by
#' the original analysis and standardises transaction date to Date.
#'
#' @param df_tran A transaction data frame.
#' @return A cleaned transaction data frame.
#' @export
clean_transactions <- function(df_tran) {
  required <- c(
    "trans_num", "cc_num", "trans_date_trans_time", "category",
    "amt", "merch_lat", "merch_long", "merch_zipcode",
    "is_fraud", "reward_points", "cashback_amt"
  )
  missing <- setdiff(required, names(df_tran))
  if (length(missing)) {
    stop("Missing transaction columns: ", paste(missing, collapse = ", "))
  }

  df_tran |>
    dplyr::distinct(dplyr::across(dplyr::all_of(required))) |>
    dplyr::mutate(
      trans_date_trans_time = as.Date(trans_date_trans_time)
    )
}

#' Aggregate transactions to customer/card/category/month
#'
#' First aggregates daily activity and then rolls it to month level.
#' `tranDay_Cnt` represents the number of distinct transaction-active days.
#'
#' @param df_tran_clean Output from [clean_transactions()].
#' @return Monthly transaction aggregation.
#' @export
aggregate_transactions <- function(df_tran_clean) {
  required <- c(
    "cc_num", "category", "trans_date_trans_time",
    "amt", "reward_points", "cashback_amt"
  )
  missing <- setdiff(required, names(df_tran_clean))
  if (length(missing)) {
    stop("Missing cleaned transaction columns: ", paste(missing, collapse = ", "))
  }

  daily <- df_tran_clean |>
    dplyr::group_by(
      category,
      cc_num,
      year_month = trans_date_trans_time
    ) |>
    dplyr::summarise(
      amt = sum(amt, na.rm = TRUE),
      reward_points = sum(reward_points, na.rm = TRUE),
      cashback_amt = sum(cashback_amt, na.rm = TRUE),
      .groups = "drop"
    ) |>
    dplyr::mutate(tranDay_Cnt = 1L)

  daily |>
    dplyr::group_by(
      category,
      cc_num,
      year_month = lubridate::floor_date(year_month, "month")
    ) |>
    dplyr::summarise(
      amt = sum(amt, na.rm = TRUE),
      reward_points = sum(reward_points, na.rm = TRUE),
      cashback_amt = sum(cashback_amt, na.rm = TRUE),
      tranDay_Cnt = sum(tranDay_Cnt, na.rm = TRUE),
      .groups = "drop"
    ) |>
    dplyr::mutate(
      days_in_month = lubridate::days_in_month(year_month)
    )
}

#' Map cards to customers
#'
#' @param df_customer Customer mapping data frame.
#' @return One row per card/customer mapping.
#' @export
map_transactions_to_customers <- function(df_customer) {
  required <- c("cc_num", "customer_id")
  missing <- setdiff(required, names(df_customer))
  if (length(missing)) {
    stop("Missing customer mapping columns: ", paste(missing, collapse = ", "))
  }

  df_customer |>
    dplyr::distinct(cc_num, customer_id)
}

#' Join monthly transaction aggregates to customers
#'
#' @param transaction_aggr Output from [aggregate_transactions()].
#' @param customer_map Output from [map_transactions_to_customers()].
#' @return Customer-level transaction aggregation.
#' @export
map_to_customers <- function(transaction_aggr, customer_map) {
  dplyr::left_join(transaction_aggr, customer_map, by = "cc_num")
}
