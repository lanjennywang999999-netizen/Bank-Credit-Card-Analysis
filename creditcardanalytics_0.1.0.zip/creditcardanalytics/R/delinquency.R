#' Transform UCI credit-card payment history to long format
#'
#' Converts PAY_0/PAY_2/PAY_3/PAY_4/PAY_5/PAY_6 into monthly observations
#' and derives delinquency and portfolio-health buckets.
#'
#' @param df_csv UCI Credit Card data.
#' @param start_month First month represented by PAY_0. Defaults to 2024-01.
#' @return Long-format delinquency data.
#' @export
transform_uci_delinquency <- function(df_csv, start_month = "2024-01") {
  required <- c("ID", "PAY_0", "PAY_2", "PAY_3", "PAY_4", "PAY_5", "PAY_6")
  missing <- setdiff(required, names(df_csv))
  if (length(missing)) {
    stop("Missing UCI columns: ", paste(missing, collapse = ", "))
  }

  pay_cols <- required[-1]
  month_values <- format(
    seq(
      as.Date(paste0(start_month, "-01")),
      by = "month",
      length.out = length(pay_cols)
    ),
    "%Y-%m"
  )

  df_csv |>
    tidyr::pivot_longer(
      cols = dplyr::all_of(pay_cols),
      names_to = "month",
      values_to = "days_past_due"
    ) |>
    dplyr::mutate(
      month = factor(month, levels = pay_cols, labels = month_values),
      month = as.character(month),
      delinquency_bucket = dplyr::case_when(
        days_past_due <= 0 ~ "Current",
        days_past_due <= 30 ~ "0-30",
        days_past_due <= 60 ~ "30-60",
        days_past_due <= 90 ~ "60-90",
        days_past_due > 90 ~ "90+",
        TRUE ~ NA_character_
      ),
      portfolio_health = dplyr::case_when(
        days_past_due <= 0 ~ "Healthy",
        days_past_due <= 60 ~ "Watchlist",
        days_past_due > 60 ~ "Risk",
        TRUE ~ NA_character_
      )
    )
}

#' Build delinquency dataset with transaction utilisation
#'
#' Joins monthly delinquency observations to customer transaction activity.
#' Utilisation is calculated as active transaction days divided by the number
#' of days in the relevant month.
#'
#' @param delinquency_data Output from [transform_uci_delinquency()].
#' @param customer_transactions Output from [map_to_customers()].
#' @return Delinquency data enriched with utilisation.
#' @export
build_delinquency_dataset <- function(delinquency_data, customer_transactions) {
  required_d <- c("ID", "month")
  required_t <- c("customer_id", "year_month", "days_in_month", "tranDay_Cnt")
  missing_d <- setdiff(required_d, names(delinquency_data))
  missing_t <- setdiff(required_t, names(customer_transactions))

  if (length(missing_d)) stop("Missing delinquency columns: ", paste(missing_d, collapse = ", "))
  if (length(missing_t)) stop("Missing transaction columns: ", paste(missing_t, collapse = ", "))

  tx <- customer_transactions |>
    dplyr::mutate(month = format(as.Date(year_month), "%Y-%m")) |>
    dplyr::group_by(customer_id, month) |>
    dplyr::summarise(
      days_in_month = dplyr::first(days_in_month),
      tranDay_Cnt = sum(tranDay_Cnt, na.rm = TRUE),
      .groups = "drop"
    )

  dplyr::left_join(
    delinquency_data,
    tx,
    by = c("ID" = "customer_id", "month" = "month")
  ) |>
    dplyr::mutate(
      utilisation_rate = dplyr::if_else(
        !is.na(days_in_month) & days_in_month > 0,
        tranDay_Cnt / days_in_month,
        NA_real_
      )
    )
}
