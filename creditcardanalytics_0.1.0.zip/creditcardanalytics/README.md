# creditcardanalytics

Reusable R functions for credit-card transaction aggregation and delinquency analytics.

## Workflow

```r
library(creditcardanalytics)

tran_clean <- clean_transactions(df_tran)
tran_monthly <- aggregate_transactions(tran_clean)

cust_map <- map_transactions_to_customers(df_customer)
tran_customer <- map_to_customers(tran_monthly, cust_map)

delinq <- transform_uci_delinquency(df_csv)
final <- build_delinquency_dataset(delinq, tran_customer)
```

## Key outputs

- Monthly transaction amount, reward points and cashback
- Transaction-active day count
- Days in month
- Customer/card mapping
- Delinquency bucket
- Portfolio health
- Monthly utilisation rate
